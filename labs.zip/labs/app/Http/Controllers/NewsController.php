<?php

namespace App\Http\Controllers;

use App\Models\News;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class NewsController extends Controller
{
    function index()
    {
        $data = News::all();
        return view('news/list', ['data' => $data]);
    }
    function add()
    {
        return view('news/addNews');
    }
    public function add_(Request $request)
    {
        // Thêm ràng buộc cho các trường dữ liệu
        $request->validate([
            'tieuDe' => 'required|string|max:255',
            'tomTat' => 'required|string',
            'urlHinh' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'idLT' => 'required|integer',
        ]);

        // Xử lý tải lên hình ảnh
        if ($request->hasFile('urlHinh')) {
            $image = $request->file('urlHinh');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('upload/images');
            $image->move($destinationPath, $imageName);

            // Tạo bản ghi mới cho bảng News
            $data = new News();
            $data->tieuDe = $request->input('tieuDe');
            $data->tomTat = $request->input('tomTat');
            $data->urlHinh = 'upload/images/' . $imageName; // Lưu tên hình ảnh vào cơ sở dữ liệu với đường dẫn tương đối
            $data->idLT = $request->input('idLT');
            $data->save();

            return redirect('/news/list')->with('success', 'News added successfully.');
        } else {
            return redirect('/news/add')->with('error', 'Image upload failed.');
        }
    }
    public function delete($id)
    {
        $data = News::find($id);
        if ($data == null) {    
            return redirect('/notification/404');
        }

        // Kiểm tra và xóa hình ảnh nếu tồn tại
        if ($data->urlHinh && file_exists(public_path($data->urlHinh))) {
            unlink(public_path($data->urlHinh));
        }

        $data->delete();

        return redirect('/news/list')->with('success', 'News deleted successfully.');
    }
    function edit($id)
    {
        $data = News::find($id);
        // từ $data->id -> lấy ra tên loại tin
        $nameCat = DB::table('loaitin')
            ->where('id', $data->idLT)
            ->value('ten');
        // $dataCat -> lấy ra tất cả loại tin trừ loại tin hiện tại
        $dataCat = DB::table('loaitin')
            ->where('id', '!=', $data->idLT)
            ->get();
        if ($data == null) {
            return redirect('/notification/404');
        }
        return view('news/editNews', ['data' => $data, 'nameCat' => $nameCat, 'dataCat' => $dataCat]);
    }
    public function edit_(Request $request, $id)
    {
        // Thêm ràng buộc cho các trường dữ liệu
        $request->validate([
            'tieuDe' => 'required|string|max:255',
            'tomTat' => 'required|string',
            'urlHinh' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'idLT' => 'required|integer',
        ]);

        // Tìm bản ghi News cần chỉnh sửa
        $data = News::find($id);
        if ($data == null) {
            return redirect('/notification/404');
        }

        // Cập nhật dữ liệu
        $data->tieuDe = $request->input('tieuDe');
        $data->tomTat = $request->input('tomTat');
        $data->idLT = $request->input('idLT');

        // Xử lý tải lên hình ảnh nếu có
        if ($request->hasFile('urlHinh')) {
            // Xóa hình ảnh cũ nếu tồn tại
            if ($data->urlHinh && file_exists(public_path($data->urlHinh))) {
                unlink(public_path($data->urlHinh));
            }

            $image = $request->file('urlHinh');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('upload/images'), $imageName);
            $data->urlHinh = 'upload/images/' . $imageName; // Cập nhật đường dẫn hình ảnh mới
        }

        $data->save();

        return redirect('/news/list')->with('success', 'News updated successfully.');
    }
    function notification_404()
    {
        return view('notification/404');
    }

    function contact()
    {
        return view('contact');
    }

    function get1news($id)
    {
        $data = ['id' => $id];
        return view('detail', $data);
    }

    function studentinformation()
    {
        return view('studentinformation');
    }
    function mostViewedNews()
    {
        $query = DB::table('tin')
            ->select('id', 'tieuDe', 'xem')
            ->orderBy('xem', 'desc')
            ->limit(10);
        $data = $query->get();
        return view('mostViewedNews', ['data' => $data]);
    }
    function newNews()
    {
        $query = DB::table('tin')
            ->select('id', 'tieuDe', 'ngayDang')
            ->orderBy('ngayDang', 'desc')
            ->limit(10);
        $data = $query->get();
        return view('newNews', ['data' => $data]);
    }
    function newsInCategory($idCat = 0)
    {
        $listNews = DB::table('tin')
            ->where('idLT', $idCat)
            ->get();

        $categoryName = DB::table('loaitin')
            ->where('id', $idCat)
            ->value('ten');

        $data = [
            'idCat' => $idCat,
            'listNews' => $listNews,
            'categoryName' => $categoryName
        ];

        return view('newsInCategory', $data);
    }

    function detail($id = 0)
    {
        $new = DB::table('tin')
            ->where('id', $id)
            ->first();
        $data = ['id' => $id, 'new' => $new];
        return view('detail', $data);
    }
}

<?php

use Illuminate\Support\Facades\DB;

$sidebar_arr = DB::table('loaitin')->select('id', 'ten')
  ->orderBy('thuTu', 'asc')
  ->where('AnHien', '=', 1)
  ->limit(5)
  ->get();
?>
<ul class="nav flex-column" style="margin-left: 12px;">
  @foreach ($sidebar_arr as $sidebar_arr)
  <li class="nav-item">
    <a class="nav-link-siderbar" href="{{url('/newsInCategory', [$sidebar_arr->id])}}">{{$sidebar_arr->ten}}</a>
  </li>
  <hr>
  @endforeach
</ul>

<style>
  .nav-link-siderbar{
    color: #000;}
</style>
@extends('layout')
@section('title')
    Home page
@endsection
@section('content')
    Content of home page
@endsection
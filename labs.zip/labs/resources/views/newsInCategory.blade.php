@extends('layout')
@section('title')
    {{$categoryName}}
@endsection
@section('content')
    <h1 style="color: #333; font-size: 2.5rem;">Tất cả tin loại {{$categoryName}}</h1>
    <hr>
    @foreach ($listNews as $new)
        <div class="row">
            <h3>
                <a style="color: #333; text-decoration: none;" href="{{url('/detail', [$new -> id])}}">{{$new -> tieuDe}}</a>
            </h3>
            <p>{{$new -> tomTat}}</p>
            <hr>
        </div>
    @endforeach
@endsection
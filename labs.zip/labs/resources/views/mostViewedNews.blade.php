<h1>Most Viewed News</h1>
<ul>

</ul>
<?php 
foreach($data as $viewedNews){
    echo "<li>{$viewedNews->tieuDe} have {$viewedNews->xem} view</li>";
}
?>

<style>
    h1{
        margin-left: 20px;
        font-size: 2.5rem;
    }
    li{
        font-size: 1.6rem;
    }
</style>
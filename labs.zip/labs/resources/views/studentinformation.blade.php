<section class="image-bg-fluid-height" id="about">
  <h1>Lường Văn Tiến</h1>
  <img class="img-responsive" src="https://yt3.googleusercontent.com/v-fHSvLthvdRlrtXeEbWc1JtuKPa7yUeG668kRdxbX6XAxcw_rlhf8wjRGxht_oepo49SkwnXA=s900-c-k-c0x00ffffff-no-rj">

  <h3>22/09/2004</h3>
  <h3>Thanh Hóa</h3>
  <h3>Student of FPT Polytectnic</h3>
</section>

<style>
    #about {
    text-align: center;
    color: white;
    margin: 0px 0 20px 0;
    padding: 50px;
}
#portfolio {
  background-color: #00b33c;
    text-align: center;
    color: white;
    margin: 0px 0 20px 0;
    padding: 20px;
}

#contact{
    text-align: center;
    color: white;
    margin: 0px 0 20px 0;
    padding: 50px;
}
img {
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 2em;
  width: 500px;
}


body { 
  padding-bottom: 70px;

  background-color: chocolate;
}

</style>
<head>
    <title>@yield('title')</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .container header {
            height: 220px
        }

        .container nav {
            height: 60px
        }

        .container footer {
            height: 90px
        }

        .container main {
            display: flex;
            min-height: 500px
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- <header>
            @include('header')
        </header> -->
        <nav>
            @include('menu')
        </nav>
        <main style="margin-top: 12px;">
            <article class="col-9 bg-light" style="padding-left: 12px;">@yield('content')</article>
            <aside class="col-3">
                @include('sidebar')
            </aside>
        </main>
        <footer>@include('footer')</footer>
    </div>
</body>
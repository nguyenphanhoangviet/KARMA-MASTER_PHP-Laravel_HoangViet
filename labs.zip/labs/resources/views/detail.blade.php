@extends('layout')
@section('title')
    News detail {{$id}}
@endsection
@section('content')
    <h2>{{$new -> tieuDe}}</h2>
    <h3>{{$new -> tomTat}}</h3>
    <div id="content">{!!$new -> noiDung!!}</div>
@endsection
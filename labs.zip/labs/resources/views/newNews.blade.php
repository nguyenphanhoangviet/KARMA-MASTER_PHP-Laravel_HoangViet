<h1>New News</h1>

<?php 
foreach($data as $newNews){
    echo "<p>{$newNews->tieuDe}</p>";
    echo "<em>Date: {$newNews->ngayDang}</em>";
    echo "<hr>";
}
?>

<style>
    h1{
        margin-left: 20px;
        font-size: 2.5rem;
    }
    p{
        font-size: 1.6rem;
    }
    em{
        font-size: 1.2rem;
    }
</style>
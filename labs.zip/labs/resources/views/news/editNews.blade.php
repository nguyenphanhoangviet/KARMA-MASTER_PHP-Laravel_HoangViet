<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<form action="/news/edit/{{ $data->id }}" method="post" class="col-7 m-auto mt-5" enctype="multipart/form-data">
    @csrf
    <div class="mb-3">
        <label for="tieuDe" class="form-label">Title:</label>
        <input type="text" name="tieuDe" id="tieuDe" class="form-control" value="{{ $data->tieuDe }}" required>
    </div>
    <div class="mb-3">
        <label for="tomTat" class="form-label">Summary:</label>
        <textarea name="tomTat" id="tomTat" class="form-control" rows="3" required>{{ $data->tomTat }}</textarea>
    </div>
    <div class="mb-3">
        <label for="urlHinh" class="form-label">UrlImage:</label>
        <input type="file" name="urlHinh" id="urlHinh" class="form-control">
        <img src="/{{ $data->urlHinh }}" alt="Current Image" class="img-thumbnail mt-2" width="150">
    </div>
    <div class="mb-3">
        <label for="idLT" class="form-label">News Category:</label>
        <select name="idLT" id="idLT" class="form-control" required>
            <option value="{{ $data->idLT }}">{{ $nameCat }}</option>
            @foreach ($dataCat as $cat)
                <option value="{{ $cat->id }}">{{ $cat->ten }}</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3 d-flex justify-content-between">
        <button type="submit" class="btn btn-warning">Edit News</button>
        <a href="/news/delete/{{ $data->id }}" class="btn btn-danger text-white text-decoration-none">Delete News</a>
    </div>
</form>

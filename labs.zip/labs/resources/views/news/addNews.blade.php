<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<form action="/news/add_" method="post" class="col-7 m-auto mt-5" enctype="multipart/form-data">
    @csrf
    <div class="mb-3">
        <label for="tieuDe" class="form-label">Title:</label>
        <input type="text" name="tieuDe" id="tieuDe" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="tomTat" class="form-label">Summary:</label>
        <textarea name="tomTat" id="tomTat" class="form-control" rows="3" required></textarea>
    </div>
    <div class="mb-3">
        <label for="urlHinh" class="form-label">UrlImage:</label>
        <input type="file" name="urlHinh" id="urlHinh" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="idLT" class="form-label">News Category:</label>
        <select name="idLT" id="idLT" class="form-control" required>
            <option value="1">Social</option>
            <option value="2">Travel</option>
        </select>
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-warning">Add News</button>
    </div>
</form>

<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;

class chenthanhvien extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $ho = ['Nguyen', 'Tran', 'Le', 'Pham', 'Hoang', 'Huynh', 'Phan', 'Vu', 'Vuong', 'Dang'];
        $lot = ['Van', 'Thi', 'Dinh', 'Duc', 'Minh', 'Huu', 'Thi', 'Thanh', 'Ngoc', ''];
        $ten = ['An', 'Binh', 'Chinh', 'Dung', 'Hai', 'Khanh', 'Linh', 'Nga', 'Quang', 'Tuan'];
        for($i=0;$i<100;$i++){
            $ht = Arr::random($ho) . ' ' . Arr::random($lot) . ' ' . Arr::random($ten);
            DB::table('thanhvien')->insert([
                'hoTen'=>$ht,
                'email'=>Str::random(5).'@gmail.com',
                'password'=>bcrypt('123'),
            ]);
        }
    }
}

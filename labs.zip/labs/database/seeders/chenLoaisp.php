<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class chenLoaisp extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('loaiSP')->insert([
            ['tenloai'=>'Sam Sung', 'thuTu'=>'1', 'anHien'=>1],
            ['tenloai'=>'HTC', 'thuTu'=>'2', 'anHien'=>1],
            ['tenloai'=>'Apple', 'thuTu'=>'3', 'anHien'=>1],
            ['tenloai'=>'LG', 'thuTu'=>'4', 'anHien'=>1],
            ['tenloai'=>'Motorola', 'thuTu'=>'5', 'anHien'=>1],
            ['tenloai'=>'Mobel', 'thuTu'=>'6', 'anHien'=>0],
        ]);
    }
}

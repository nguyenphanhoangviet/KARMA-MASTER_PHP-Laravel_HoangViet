<?php

use Illuminate\Support\Facades\DB;

$sidebar_arr = DB::table('loaitin')->select('id', 'ten')
  ->orderBy('thuTu', 'asc')
  ->where('AnHien', '=', 1)
  ->limit(5)
  ->get();
?>
<ul class="nav flex-column" style="margin-left: 12px;">
  <?php $__currentLoopData = $sidebar_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebar_arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="nav-item">
    <a class="nav-link-siderbar" href="<?php echo e(url('/newsInCategory', [$sidebar_arr->id])); ?>"><?php echo e($sidebar_arr->ten); ?></a>
  </li>
  <hr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<style>
  .nav-link-siderbar{
    color: #000;}
</style><?php /**PATH /opt/lampp/htdocs/code/PHP3/test1/resources/views/sidebar.blade.php ENDPATH**/ ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<div class="container">
<div class="d-flex flex-wrap align-items-center mb-3 custom-flex">
    <h1 class="me-auto custom-heading">List News</h1>
    <a href="/news/add" class="btn btn-warning text-white">Add News</a>
</div>


    <div class="row mb-3">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($new->tieuDe); ?></h5>
                            <img height="200px" src="<?php echo e(url('/' . ltrim($new->urlHinh, '/'))); ?>" class="card-img-top" alt="<?php echo e($new->tieuDe); ?>">
                            <p class="card-text"><?php echo e($new->tomTat); ?></p>
                            <a href="/news/edit/<?php echo e($new->id); ?>" class="btn btn-warning text-white">Update</a>
                            <a href="/news/delete/<?php echo e($new->id); ?>" class="btn btn-danger text-white">Delete</a>
                        </div>
                    </div>
                </div>
                <?php if(($index + 1) % 3 == 0): ?>
                    </div><div class="row mb-3">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>
<style>
.card-title {
    white-space: nowrap; /* Prevent the text from wrapping */
    overflow: hidden;    /* Hide any overflow text */
    text-overflow: ellipsis; /* Show ellipsis (...) for overflow text */
}
.card-text {
    display: -webkit-box;        /* Required for multiline truncation */
    -webkit-line-clamp: 4;       /* Number of lines to show */
    -webkit-box-orient: vertical; /* Required for multiline truncation */
    overflow: hidden;            /* Hide any overflow text */
    text-overflow: ellipsis;     /* Show ellipsis (...) for overflow text */
    height: 96px;
}
.custom-flex {
    gap: 1rem; /* Optional: Adds spacing between flex items */
}

.custom-flex h1 {
    margin: 0; /* Removes default margin of the h1 element */
}

.custom-flex .btn {
    font-size: 1rem; /* Ensures consistent button text size */
}
.custom-heading {
    font-size: 2rem; /* Adjust the font size */
    font-weight: bold; /* Make the text bold */
    color: #333; /* Change the text color */
    margin: 0; /* Remove default margins */
    padding: 0; /* Remove default padding */
    line-height: 1.2; /* Adjust line height for better spacing */
}
</style><?php /**PATH /opt/lampp/htdocs/code/PHP3/labs4/resources/views/news/list.blade.php ENDPATH**/ ?>
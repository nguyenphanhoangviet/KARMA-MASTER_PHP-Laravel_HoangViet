<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .container header {
            height: 220px
        }

        .container nav {
            height: 60px
        }

        .container footer {
            height: 90px
        }

        .container main {
            display: flex;
            min-height: 500px
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- <header>
            <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header> -->
        <nav>
            <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <main style="margin-top: 12px;">
            <article class="col-9 bg-light" style="padding-left: 12px;"><?php echo $__env->yieldContent('content'); ?></article>
            <aside class="col-3">
                <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
        </main>
        <footer><?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></footer>
    </div>
</body><?php /**PATH /opt/lampp/htdocs/code/PHP3/labs4/resources/views/layout.blade.php ENDPATH**/ ?>
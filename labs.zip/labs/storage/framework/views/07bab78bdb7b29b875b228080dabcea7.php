<?php $__env->startSection('title'); ?>
    <?php echo e($categoryName); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1 style="color: #333; font-size: 2.5rem;">Tất cả tin loại <?php echo e($categoryName); ?></h1>
    <hr>
    <?php $__currentLoopData = $listNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <h3>
                <a style="color: #333; text-decoration: none;" href="<?php echo e(url('/detail', [$new -> id])); ?>"><?php echo e($new -> tieuDe); ?></a>
            </h3>
            <p><?php echo e($new -> tomTat); ?></p>
            <hr>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/PHP3/labs4/resources/views/newsInCategory.blade.php ENDPATH**/ ?>
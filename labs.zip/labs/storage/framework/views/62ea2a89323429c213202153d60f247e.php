<?php $__env->startSection('title'); ?>
    Home page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    Content of home page
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/PHP3/test1/resources/views/index.blade.php ENDPATH**/ ?>
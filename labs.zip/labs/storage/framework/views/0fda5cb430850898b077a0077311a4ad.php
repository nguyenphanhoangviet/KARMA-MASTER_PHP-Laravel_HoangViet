<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<form action="/news/add" method="post" class="col-7 m-auto">
    <p>Title: <input name="tieuDe" class="form-control"></p>
    <p>Summary: <textarea name="tomTat" class="form-control"></textarea></p>
    <p>UrlImage: <input name="urlHinh" class="form-control"></p>
    <p>idNewsCategory <select name="idLT" class="form-control">
        <option value="1">Social</option>
        <option value="2">Travel</option>
    </select></p>
    <p><button type="submit" class="bg-warning p-2">Add News</button></p>
    <?php echo csrf_field(); ?>
</form>
<?php /**PATH /opt/lampp/htdocs/code/PHP3/labs/resources/views/news/addNews.blade.php ENDPATH**/ ?>
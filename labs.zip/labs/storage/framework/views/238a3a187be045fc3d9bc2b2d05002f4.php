<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<form action="/news/edit/<?php echo e($data->id); ?>" method="post" class="col-7 m-auto">
            <?php echo csrf_field(); ?>
            <p>Title: <input name="tieuDe" class="form-control" value="<?php echo e($data->tieuDe); ?>"></p>
            <p>Summary: <textarea name="tomTat" class="form-control"><?php echo e($data->tomTat); ?></textarea></p>
            <p>UrlImage: <input name="urlHinh" class="form-control" value="<?php echo e($data->urlHinh); ?>"></p>
            <p>idNewsCategory: 
                <select name="idLT" class="form-control">
                        <!-- <option value="1" <?php echo e($data->idLT == 1 ? 'selected' : ''); ?>>Social</option>
                        <option value="2" <?php echo e($data->idLT == 2 ? 'selected' : ''); ?>>Travel</option> -->
                       <!-- option dau tien gia trị nhận $data->idLT -->
                          <option value="<?php echo e($data->idLT); ?>"><?php echo e($nameCat); ?></option>
                        <!-- option sau là các giá trị còn lại -->
                        <?php $__currentLoopData = $dataCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->ten); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </p>
            <p><button type="submit" class="bg-warning p-2">Edit News</button>
            <!-- add button delete -->
            <a href="/news/delete/<?php echo e($data->id); ?>" class="bg-danger p-2 text-white text-decoration-none">Delete News</a>
        </p>
        </form>
<?php /**PATH /opt/lampp/htdocs/code/PHP3/labs/resources/views/news/editNews.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    News detail <?php echo e($id); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e($new -> tieuDe); ?></h2>
    <h3><?php echo e($new -> tomTat); ?></h3>
    <div id="content"><?php echo $new -> noiDung; ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/PHP3/labs4/resources/views/detail.blade.php ENDPATH**/ ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<div class="alert alert-info p-5 shadow-lg border-2 border border-info m-5 fs-3 text-center">
        <h1>Notification</h1>
        <p>id does not exist</p>
    </div><?php /**PATH /opt/lampp/htdocs/code/PHP3/labs/resources/views/notification/404.blade.php ENDPATH**/ ?>
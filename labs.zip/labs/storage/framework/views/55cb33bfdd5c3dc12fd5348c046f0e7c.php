<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<form action="/news/edit/<?php echo e($data->id); ?>" method="post" class="col-7 m-auto mt-5" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="tieuDe" class="form-label">Title:</label>
        <input type="text" name="tieuDe" id="tieuDe" class="form-control" value="<?php echo e($data->tieuDe); ?>" required>
    </div>
    <div class="mb-3">
        <label for="tomTat" class="form-label">Summary:</label>
        <textarea name="tomTat" id="tomTat" class="form-control" rows="3" required><?php echo e($data->tomTat); ?></textarea>
    </div>
    <div class="mb-3">
        <label for="urlHinh" class="form-label">UrlImage:</label>
        <input type="file" name="urlHinh" id="urlHinh" class="form-control">
        <img src="/<?php echo e($data->urlHinh); ?>" alt="Current Image" class="img-thumbnail mt-2" width="150">
    </div>
    <div class="mb-3">
        <label for="idLT" class="form-label">News Category:</label>
        <select name="idLT" id="idLT" class="form-control" required>
            <option value="<?php echo e($data->idLT); ?>"><?php echo e($nameCat); ?></option>
            <?php $__currentLoopData = $dataCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->ten); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3 d-flex justify-content-between">
        <button type="submit" class="btn btn-warning">Edit News</button>
        <a href="/news/delete/<?php echo e($data->id); ?>" class="btn btn-danger text-white text-decoration-none">Delete News</a>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\laravel\lab1\labs\resources\views/news/editNews.blade.php ENDPATH**/ ?>
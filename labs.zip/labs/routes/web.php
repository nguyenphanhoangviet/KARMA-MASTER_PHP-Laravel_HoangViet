<?php

use App\Http\Controllers\NewsController;
use Illuminate\Support\Facades\Route;

Route::get('/', [NewsController::class, 'index']);
Route::get('/contact', [NewsController::class, 'contact']);
Route::get('/detail/{id}', [NewsController::class, 'detail']);
Route::get('/studentinformation', [NewsController::class, 'studentinformation']);
Route::get('/mostViewedNews', [NewsController::class, 'mostViewedNews']);
Route::get('/newNews', [NewsController::class, 'newNews']);
Route::get('/newsInCategory/{id}', [NewsController::class, 'newsInCategory']);
Route::get('/news/list', [NewsController::class, 'index']);
Route::get('/news/add', [NewsController::class, 'add']);
Route::post('/news/add_', [NewsController::class, 'add_']);
Route::get('/news/delete/{id}', [NewsController::class, 'delete']);
Route::get('/news/edit/{id}', [NewsController::class, 'edit']);
Route::post('/news/edit/{id}', [NewsController::class, 'edit_']);
Route::get('/notification/404', [NewsController::class, 'notification_404']);

